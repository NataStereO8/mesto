# Project 4: Mesto (Sndk)

### About project

This project makes it possible to view information about the places visited by the traveler. But we slightly modernized the project and provided you with information about the magical worlds voiced by Sndk. 

You can:

* edit information about person

**Tools**

* HTML
* CSS
* JavaScript

**Next version**

* add functionality for setting likes
* add new places

**Project link**

[Ссылка на проект](https://natastereo8.github.io/mesto/)
